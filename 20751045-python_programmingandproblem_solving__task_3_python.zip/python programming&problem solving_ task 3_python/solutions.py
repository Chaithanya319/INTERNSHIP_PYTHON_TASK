
# ==========================================================
# TASK 3: PYTHON CODING AND PROBLEM-SOLVING
# File: solutions.py
# ==========================================================


# Q1. Find the Frequency of Each Word in a Sentence

def word_frequency(sentence):
    frequency = {}

    for word in sentence.split():
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1

    return frequency


# Q2. Find the Frequency of Each Character in a Word

def character_frequency(word):
    frequency = {}

    for character in word:
        if character in frequency:
            frequency[character] += 1
        else:
            frequency[character] = 1

    return frequency


# Q3. Find the First Non-Repeating Character in a Word

def first_non_repeating_character(word):
    frequency = character_frequency(word)

    for character in word:
        if frequency[character] == 1:
            return character

    return None


# Q4. Check Whether Two Strings Are Anagrams

def are_anagrams(s1, s2):
    s1 = s1.replace(" ", "").lower()
    s2 = s2.replace(" ", "").lower()

    return character_frequency(s1) == character_frequency(s2)


# Q5. Find the First Repeating Character in a String

def first_repeating_character(text):
    seen = set()

    for character in text:
        if character in seen:
            return character

        seen.add(character)

    return None


# Q6. Move All Zeros to the End of a List

def move_zeros_to_end(nums):
    non_zeros = []
    zeros = []

    for number in nums:
        if number == 0:
            zeros.append(number)
        else:
            non_zeros.append(number)

    return non_zeros + zeros


# Q7. Find the Second Highest Distinct Number in a List

def second_highest_distinct(nums):
    unique_numbers = sorted(set(nums), reverse=True)

    if len(unique_numbers) < 2:
        return None

    return unique_numbers[1]


# Q8. Remove Duplicates Without Changing the Original Order

def remove_duplicates_preserve_order(nums):
    result = []
    seen = set()

    for number in nums:
        if number not in seen:
            result.append(number)
            seen.add(number)

    return result


# Q9. Find the Missing Number from 1 to N

def find_missing_number(nums, n):
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)

    return expected_sum - actual_sum


# Q10. Find Two Numbers Whose Sum Equals a Target

def two_sum_first_pair(nums, target):
    seen_numbers = []

    for number in nums:
        complement = target - number

        for earlier_number in seen_numbers:
            if earlier_number == complement:
                return [earlier_number, number]

        seen_numbers.append(number)

    return []


# Q11. Find the Number Closest to Zero

def closest_to_zero(nums):
    if not nums:
        return None

    return min(nums, key=lambda number: (abs(number), -number))


# Q12. Find Common Elements Between Two Lists

def common_elements(list1, list2):
    second_list = set(list2)

    result = []
    seen = set()

    for number in list1:
        if number in second_list and number not in seen:
            result.append(number)
            seen.add(number)

    return result


# Q13. Rotate a List to the Right by K Positions

def rotate_right(nums, k):
    if not nums:
        return []

    k = k % len(nums)

    if k == 0:
        return nums[:]

    return nums[-k:] + nums[:-k]


# Q14. Find the Maximum Sum of Two Consecutive Elements

def max_consecutive_pair_sum(nums):
    if len(nums) < 2:
        raise ValueError("The list must contain at least two elements.")

    maximum_sum = nums[0] + nums[1]

    for index in range(1, len(nums) - 1):
        current_sum = nums[index] + nums[index + 1]

        if current_sum > maximum_sum:
            maximum_sum = current_sum

    return maximum_sum


# Q15. Find All Pairs Whose Sum Equals a Target

def all_unique_pairs(nums, target):
    pairs = set()

    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                pair = tuple(sorted((nums[i], nums[j])))
                pairs.add(pair)

    return [list(pair) for pair in sorted(pairs)]

