
# ============================================================
# TASK 3: PYTHON CODING & PROBLEM-SOLVING
# File: main.py
# Import and test all 15 functions from solutions.py
# ============================================================


from solutions import (
    word_frequency,
    character_frequency,
    first_non_repeating_character,
    are_anagrams,
    first_repeating_character,
    move_zeros_to_end,
    second_highest_distinct,
    remove_duplicates_preserve_order,
    find_missing_number,
    two_sum_first_pair,
    closest_to_zero,
    common_elements,
    rotate_right,
    max_consecutive_pair_sum,
    all_unique_pairs
)


# Q1. Find the Frequency of Each Word in a Sentence

print("\nQ1. Word Frequency")

sentence = "python is easy and python is powerful"
print("Original:", word_frequency(sentence))

sentence2 = "apple mango apple orange mango apple"
print("Additional:", word_frequency(sentence2))


# Q2. Find the Frequency of Each Character in a Word

print("\nQ2. Character Frequency")

word = "banana"
print("Original:", character_frequency(word))

word2 = "programming"
print("Additional:", character_frequency(word2))


# Q3. Find the First Non-Repeating Character in a Word

print("\nQ3. First Non-Repeating Character")

print("Original:", first_non_repeating_character("swiss"))
print("Additional:", first_non_repeating_character("aabb"))


# Q4. Check Whether Two Strings Are Anagrams

print("\nQ4. Check Anagrams")

print("Original:", are_anagrams("listen", "silent"))
print("Additional:", are_anagrams("hello", "world"))


# Q5. Find the First Repeating Character in a String

print("\nQ5. First Repeating Character")

print("Original:", first_repeating_character("programming"))
print("Additional:", first_repeating_character("abcdef"))


# Q6. Move All Zeros to the End of a List

print("\nQ6. Move Zeros to the End")

print("Original:", move_zeros_to_end([0, 3, 0, 1, 2, 0, 4]))
print("Additional:", move_zeros_to_end([0, 0, 5, 6]))


# Q7. Find the Second Highest Distinct Number in a List

print("\nQ7. Second Highest Distinct Number")

print("Original:", second_highest_distinct([10, 20, 40, 30, 40, 20]))
print("Additional:", second_highest_distinct([7, 7, 7]))


# Q8. Remove Duplicates Without Changing the Original Order

print("\nQ8. Remove Duplicates")

print("Original:", remove_duplicates_preserve_order([4, 2, 4, 5, 2, 7, 5]))
print("Additional:", remove_duplicates_preserve_order([1, 1, 2, 3, 2]))


# Q9. Find the Missing Number from 1 to N

print("\nQ9. Find Missing Number")

print("Original:", find_missing_number([1, 2, 4, 5, 6], 6))
print("Additional:", find_missing_number([1, 3, 4], 4))


# Q10. Find Two Numbers Whose Sum Equals a Target

print("\nQ10. Two Sum")

print("Original:", two_sum_first_pair([2, 7, 11, 15], 9))
print("Additional:", two_sum_first_pair([1, 4, 2, 3], 5))


# Q11. Find the Number Closest to Zero

print("\nQ11. Number Closest to Zero")

print("Original:", closest_to_zero([-8, -3, 2, 5, -2]))
print("Additional:", closest_to_zero([-4, 4, -1]))


# Q12. Find Common Elements Between Two Lists

print("\nQ12. Common Elements")

print(
    "Original:",
    common_elements([1, 2, 3, 4, 5], [3, 4, 5, 6, 7])
)

print(
    "Additional:",
    common_elements([2, 2, 1, 3], [3, 2, 2])
)


# Q13. Rotate a List to the Right by K Positions

print("\nQ13. Rotate List Right")

print("Original:", rotate_right([1, 2, 3, 4, 5], 2))
print("Additional:", rotate_right([10, 20, 30], 4))


# Q14. Find the Maximum Sum of Two Consecutive Elements

print("\nQ14. Maximum Consecutive Pair Sum")

print("Original:", max_consecutive_pair_sum([4, 7, 2, 9, 5]))
print("Additional:", max_consecutive_pair_sum([-5, -2, -8]))


# Q15. Find All Pairs of Numbers Whose Sum Equals a Target

print("\nQ15. All Unique Pairs")

print(
    "Original:",
    all_unique_pairs([2, 4, 3, 5, 7, 8, 1], 9)
)

print(
    "Additional:",
    all_unique_pairs([1, 1, 2, 2, 3, 4], 4)
)


# End of Task 3

print("\nAll 15 questions executed successfully!")
